Mini Game Collection
====================

This project contains four simple mini-games:
1. Clicker Game
2. Memory Game
3. Math Challenge
4. Quiz Game

To host this collection:
- Upload all files to a web server or use GitHub Pages for free hosting.

Enjoy!